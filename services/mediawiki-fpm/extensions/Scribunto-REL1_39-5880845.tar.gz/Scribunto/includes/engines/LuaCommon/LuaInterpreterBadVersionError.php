<?php

class Scribunto_LuaInterpreterBadVersionError extends MWException {
}
