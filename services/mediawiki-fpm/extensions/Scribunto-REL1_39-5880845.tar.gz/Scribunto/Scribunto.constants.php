<?php
// This file is not loaded by MediaWiki, and exists purely
// for static analysis purposes

define( 'NS_MODULE', 828 );
define( 'NS_MODULE_TALK', 829 );
